package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

/**
 * This class is an empty class for the fragment
 *
 * @extends AppCompatActivity
 * */
public class EcarEmpty extends AppCompatActivity {

    /**
     * @param savedInstanceState
     * */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ecar_empty);

        Bundle dataToPass = getIntent().getExtras(); //get the data that was passed from FragmentExample
        EcarDetailFragment dFragment = new EcarDetailFragment();
        dFragment.setArguments( dataToPass ); //pass data to the the fragment
        dFragment.setTablet(false); //tell the Fragment that it's on a phone.
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.ecar_fragmentLocation, dFragment)
                .addToBackStack("AnyName")
                .commit();
    }

    /**
     * When the back button has pressed, finish the activity
     * */
    @Override
    public void onBackPressed() {
        finish();
        super.onBackPressed();
    }
}
