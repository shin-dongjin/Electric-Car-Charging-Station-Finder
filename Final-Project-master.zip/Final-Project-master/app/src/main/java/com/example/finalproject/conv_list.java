package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class conv_list extends AppCompatActivity {
    ArrayList<String> list = new ArrayList<String>(Arrays.asList
            ("USD - US Dollar","JPY - Japanese yen","BGN - Bulgarian lev","CZK - Czech koruna","DKK - Danish krone","GBP - Pound Sterling","HUF - Hungarian forint","PLN - Polish zloty","RON - Romanian leu","SEK - Swedish krona","CHF - Swiss franc",
                    "ISK - Icelandic krona","NOK - Norwegian krone","HRK - Croatian kuna","RUB - Russian rouble","TRY - Turkish lira","AUD - Australian dollar","BRL - Brazilian real","CAD - Canadian dollar","CNY - Chinese yuan renminbi","HKD - Hong Kong dollar",
                    "IDR - Indonesian rupiah","ILS - Israeli shekel","INR - Indian rupee","KRW - South Korean won","MXN - Mexican peso","MYR - Malaysian ringgit","NZD - New Zealand dollar","PHP - Philippine peso","SGD - Singapore dollar","THB - Thai baht","ZAR - South African rand"));

    BaseAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conv_list);
        ListView myList = findViewById(R.id.conv_list);
        myList.setAdapter(adapter = new ListAdapter());
        myList.setOnItemClickListener( ( lv, vw, pos, id) ->{

            Toast.makeText( conv_list.this,
                    "You clicked on:" + pos, Toast.LENGTH_SHORT).show();

        } );
    }

    private class ListAdapter extends BaseAdapter {

        /**
         * Tells the program how many objects to show
         * @return list.size()*/
        public int getCount() {
            return list.size();  }

        /**
         * Retrieves the array item at specific position
         * @param position
         * @return returns string at position*/
        public String getItem(int position) {
            return list.get(position);  }

        /**
         * Returns the id of the item at position
         * @param p
         * @return p*/
        public long getItemId(int p) {
            return p; }

        /**
         * Sets object value in layout and inflates the view into list view*/
        public View getView(int p, View recycled, ViewGroup parent)
        {
            View thisRow = recycled;

            if(recycled == null){

                thisRow = getLayoutInflater().inflate(R.layout.currency_type_list, null);
                TextView itemText = thisRow.findViewById(R.id.checkBoxCurrency );
                itemText.setText( getItem(p));

            }


            return thisRow;
        }


    }
}
