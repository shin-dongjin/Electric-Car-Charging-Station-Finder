package com.example.finalproject;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;


//ASYNC task to get the info from the url
public class NewsQuery extends AsyncTask<String, Integer, String> {

    //arraylist that puts the strings into the list from each article
    private ArrayList<String> newsInfo = new ArrayList<>(Arrays.asList());
    private String title;
    private String description;
    private String icon;
    private String webUrl;
    Button openWebsite;
    Bitmap image = null;

    private ProgressBar progressBar;
    private ArrayList<NewsArticle> list;
    private String key;
    private BaseAdapter adaptor;

    public NewsQuery(ProgressBar bar, ArrayList<NewsArticle> list, String key, BaseAdapter adaptor) {
        this.progressBar = bar;
        this.list = list;
        this.key = key;
        this.adaptor = adaptor;
    }

    // String key =  searchKey.getText().toString();
    @Override                       //Type 1
    protected String doInBackground(String... args) {
        Log.i(this.getClass().getName(), "Searching for news with key '" + key + "'");
        String ret = null;

        // a4e1d0f8d12649cd9faf1e4bbc8f0b7f
        String queryURL = "https://newsapi.org/v2/everything?q=" + key + "&apiKey=a4e1d0f8d12649cd9faf1e4bbc8f0b7f";
        //String queryURL = "https://newsapi.org/v2/everything?q=bitcoin&apiKey=a4e1d0f8d12649cd9faf1e4bbc8f0b7f";
        // String queryURL = "https://api.openweathermap.org/data/2.5/weather?q=ottawa,ca&APPID=7e943c97096a9784391a981c4d878b22&mode=xml&units=metric";
        try {

            URL urlNews = new URL(queryURL);
            HttpURLConnection UVurlConnection = (HttpURLConnection) urlNews.openConnection();

            Log.i(this.getClass().getName(), "News URL  " + queryURL);
            InputStream inStreamUV = UVurlConnection.getInputStream();

            BufferedReader buffer = new BufferedReader(new InputStreamReader(inStreamUV, "utf-8"), 8);


            //must search for the news article by title, add them to a list view. then based on the list you click on the news article and it displays all the info that you need
            // click on the item, with an intent to store the array position,

            //GSON that helps with the conversion of data from the JSON and url data
            Gson newsArticles = new Gson();

            NewsQuery.NewsJSON newsjson = newsArticles.fromJson(buffer, NewsQuery.NewsJSON.class);
            list.addAll(newsjson.articles);

        } catch (MalformedURLException mfe) {
            ret = "Malformed URL exception";
        } catch (IOException ioe) {
            ret = "IO Exception. Is the Wifi connected?";
        }


        //return the values
        return ret;
    }

    // put the values from the URL getAttributes into the execute method
    @Override                   //Type 3
    protected void onPostExecute(String valuesOfStrings) {
        super.onPostExecute(valuesOfStrings);
        progressBar.setVisibility(View.INVISIBLE);
        Log.i(this.getClass().getName(), "Got " + list.size() + " news articles for key " + key + " list id " + list);

        adaptor.notifyDataSetChanged();
    }

    @Override                       //Type 2
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        progressBar.setProgress(values[0]);
        progressBar.setVisibility(View.VISIBLE);
        //Update GUI stuff only:


    }
//this is the list that has the articles that then we grab the info from each individual article
    private class NewsJSON {
        ArrayList<NewsArticle> articles;
    }
}
