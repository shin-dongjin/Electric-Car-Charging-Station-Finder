package com.example.finalproject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
/**
 * @author Zhi
 * @version 1*/
public class CurrencyDetailFragment extends Fragment {

    private boolean isTablet;
    private Bundle dataFromActivity;
    private long id;
    private long posId;

    public void setTablet(boolean tablet) { isTablet = tablet; }

    /**
     * This method checks if the device is phone or tablet then launches the correct layout
     * When deleting from tablet it calls the method {@link favourite_conversion#deleteMessageId(int, int)} directly to delete
     * When deleting from phone it launches {@link CurrencyEmpty} which redirects back to delete*/
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        dataFromActivity = getArguments();
        id = dataFromActivity.getLong(favourite_conversion.ITEM_ID );
        posId = dataFromActivity.getLong(favourite_conversion.ITEM_POSID);
        // Inflate the layout for this fragment
        View result =  inflater.inflate(R.layout.currency_fragment_layout, container, false);

        //show the message
        TextView message = (TextView)result.findViewById(R.id.message);
        message.setText(dataFromActivity.getString(favourite_conversion.ITEM_SELECTED));
        TextView sent = result.findViewById(R.id.sentOrNot);

        //show the id:
        TextView idView = (TextView)result.findViewById(R.id.idText);
        idView.setText("ID=" + id);

        // get the delete button, and add a click listener:
        ImageButton deleteButton = result.findViewById(R.id.deleteButton);
        deleteButton.setOnClickListener( clk -> {

            if(isTablet) { //both the list and details are on the screen:
                favourite_conversion parent = (favourite_conversion)getActivity();
                parent.deleteMessageId((int)id,(int)posId); //this deletes the item and updates the list

                //now remove the fragment since you deleted it from the database:
                // this is the object to be removed, so remove(this):
                parent.getSupportFragmentManager().beginTransaction().remove(this).commit();


            }
            //for Phone:
            else //You are only looking at the details, you need to go back to the previous list page
            {
                CurrencyEmpty parent = (CurrencyEmpty) getActivity();
                Intent backToFragmentExample = new Intent();
                backToFragmentExample.putExtra(favourite_conversion.ITEM_ID, dataFromActivity.getLong(favourite_conversion.ITEM_ID ));

                parent.setResult(Activity.RESULT_OK, backToFragmentExample); //send data back to FragmentExample in onActivityResult()
                parent.finish(); //go back
            }
        });
        return result;
    }


}
