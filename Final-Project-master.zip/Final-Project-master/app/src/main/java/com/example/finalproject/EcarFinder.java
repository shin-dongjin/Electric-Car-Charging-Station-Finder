package com.example.finalproject;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

/**
 *  The Electric Car Charging Station finder using openchargemap.org api
 *  displays location title, latitude, longitude and phone number
 *  resulted by user's input.
 *
 * @author Dongjin Shin
 * @Version 1.0
 * */
public class EcarFinder extends AppCompatActivity {
    ArrayList<String> titleResults = new ArrayList<>();
    ArrayList<String> latResults = new ArrayList<>();
    ArrayList<String> lonResults = new ArrayList<>();
    ArrayList<String> phoneResults = new ArrayList<>();
    ArrayList<String> addressResults = new ArrayList<>();
    ArrayList<String> postcodeResults = new ArrayList<>();
    private BaseAdapter myAdapter;
    private String userLat, userLon;
    final Context context = this;
    ListView theList;

    /**
     * This is the create method which makes get the user input
     * and display the list of results
     *
     * @param savedInstanceState
     * @return null
     * */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ecar_finder);

        Toolbar tbar = (Toolbar)findViewById(R.id.eCarToolbar);
        setSupportActionBar(tbar);

        // When the item has clicked, display the detail information
        theList = findViewById(R.id.eCarList);
        theList.setOnItemClickListener((parent, view, position, id) -> {
            Intent showDetail = new Intent(this, EcarDisplayDetail.class);
            showDetail.putExtra("title", titleResults.get(position));
            showDetail.putExtra("lat", latResults.get(position));
            showDetail.putExtra("lon", lonResults.get(position));
            showDetail.putExtra("phone", phoneResults.get(position));
            showDetail.putExtra("address", addressResults.get(position));
            showDetail.putExtra("postcode", postcodeResults.get(position));

            startActivity(showDetail);
        });

        // To get user input of Latitude and Longitude
        Button findButton = findViewById(R.id.eCarFindB);
        EditText editLat = findViewById(R.id.editLat);
        EditText editLon = findViewById(R.id.editLon);

        SharedPreferences prefs = getSharedPreferences("FileName", MODE_PRIVATE);
        String previousLat = prefs.getString("ReserveName Lat", "");
        String previousLon = prefs.getString("ReserveName Lon", "");
        editLat.setText(previousLat);
        editLon.setText(previousLon);

        // search the result
        findButton.setOnClickListener(clk -> {

            ProgressBar pBar = findViewById(R.id.eCarProgressBar);
            pBar.setVisibility(View.VISIBLE);

            titleResults.clear();
            userLat = editLat.getText().toString();
            userLon = editLon.getText().toString();

            // If user entered nothing on either of the edit texts
            // make a toast notification
            if(userLat.trim().equals("") || userLon.trim().equals(""))
                Toast.makeText(this, "Please Enter Latitude and Longitude", Toast.LENGTH_SHORT).show();
            else {
                runQuery();
            }
        });


    }

    /**
     * This is to display the data has gotten from the api
     * shows on the list view
     * */
    private class MyListAdapter extends BaseAdapter {
        /**
         * This method is to count the number of results
         *
         * @return int
         * */
        public int getCount() {
            return titleResults.size();
        } //This function tells how many objects to show

        /**
         * This method is to get the item on the position
         *
         * @Param position
         * @return String
         * */
        public String getItem(int position) {
            return titleResults.get(position);
        }  //This returns the string at position p

        /**
         * This method is to get the item's id
         *
         * @Param p
         * @return long
         * */
        public long getItemId(int p) {
            return p;
        } //This returns the database id of the item at position p

        /**
         * This method is to specify how each row look like
         *
         * @Param p, recycled, parent
         * @return View
         * */
        public View getView(int p, View recycled, ViewGroup parent) {
            View thisRow = recycled;
            TextView result;
            if(thisRow == null){
                thisRow = getLayoutInflater().inflate(R.layout.ecar_list_layout, null);
                result = thisRow.findViewById(R.id.resultsList);
                result.setText(getItem(p));
            }else{}
            return thisRow;
        }
    } //End of Class MyListAdapter

    /**
     * This method is to initiate EcarFindQuery class
     * and execute the object
     *
     * */
    private void runQuery()
    {
        EcarFindQuery theQuery = new EcarFindQuery();
        theQuery.execute( );
    }

    /**
     * This inner class is to get the data from api and run AsyncTask
     * */
    class EcarFindQuery extends AsyncTask<String, Integer, String> {
        private JSONObject jOperatorInfo;
        private JSONObject jAddressInfo;
        private String title, latitude, longitude, phone, address, postcode;

        /**
         * This method is to read the data from url using network access that has JSON format.
         * It reads and saves the data in ArrayList
         *
         * @Param strings
         * @Return String
         * */
        @Override
        protected String doInBackground(String... strings) {
            String ret = null;
            String url = "https://api.openchargemap.io/v3/poi/?output=json&countrycode=CA&latitude="+userLat+"&longitude="+userLon+"&maxresults=10";
            try {
                // Connect to the server:
                URL eCarFindUrl = new URL(url);
                HttpURLConnection eCarUrlConnection = (HttpURLConnection) eCarFindUrl.openConnection();
                InputStream eCarInStream = eCarUrlConnection.getInputStream();

                //Reading JSON Data
                BufferedReader reader = new BufferedReader(new InputStreamReader(eCarInStream, "UTF-8"), 8);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null)
                {
                    sb.append(line);
                    publishProgress(25);
                }
                String result = sb.toString();
                JSONArray jArray = new JSONArray(result);
                for (int i=0; i < jArray.length(); i++) {
                    try {
                        jOperatorInfo = jArray.getJSONObject(i).getJSONObject("OperatorInfo");
                        jAddressInfo = jArray.getJSONObject(i).getJSONObject("AddressInfo");

//                        title = jOperatorInfo.getString("Title");
                        title = jAddressInfo.getString("Title");
                        latitude = jAddressInfo.getString("Latitude");
                        longitude = jAddressInfo.getString("Longitude");
                        phone = jOperatorInfo.getString("PhonePrimaryContact");

                        address = jAddressInfo.getString("AddressLine1");
                        postcode = jAddressInfo.getString("Postcode");

                        titleResults.add(title);
                        latResults.add(latitude);
                        lonResults.add(longitude);
                        phoneResults.add(phone);

                        addressResults.add(address);
                        postcodeResults.add(postcode);

                        publishProgress(50);

                    } catch (JSONException e) {}
                }
            }
            catch(MalformedURLException mfe){ ret = "Malformed URL exception"; }
            catch(IOException ioe)          { ret = "IO Exception. Is the Wifi connected?";}
            catch (JSONException e) { e.printStackTrace(); }
            //What is returned here will be passed as a parameter to onPostExecute:
            return ret;
        }

        /**
         * This method is to update an progress indicator or information on GUI
         *
         * @Param values
         * @Return void
         * */
        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            ProgressBar pBar = findViewById(R.id.eCarProgressBar);
            pBar.setVisibility(View.VISIBLE);
            pBar.setProgress(values[0]);
        }

        /**
         * This method get the same object from parameter that was returned by doInBackground()
         *
         * @Param sentFromDoInBackground
         * @Return void
         * */
        @Override
        protected void onPostExecute(String sentFromDoInBackground) {
            super.onPostExecute(sentFromDoInBackground);
            findViewById(R.id.eCarProgressBar).setVisibility(View.INVISIBLE);

            theList.setAdapter( myAdapter = new MyListAdapter() );
        }
    }

    /**
     * This method is to create option menu
     *
     * @Param menu
     * @Return boolean
     * */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu items for use in the action bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.ecar_toolbar_menu, menu);

        return true;
    }

    /**
     * This method is to do functions on each selected item
     *
     * @Param item MenuItem
     * @Return boolean
     * */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId())
        {
            //what to do when the menu item is selected:
            case R.id.ecarHelp:
                showDialogBox();
                break;
            case R.id.ecarFav:
                // move to favorite list acitivity list
                Intent showFavList = new Intent(this, EcarFavorite.class);
                startActivity(showFavList);
                break;
        }
        return true;
    }

    /**
     * This method is to show dialog
     * */
    public void showDialogBox(){
        View middle = getLayoutInflater().inflate(R.layout.ecar_dialog_extra, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Instruction")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // What to do on Accept
                    }
                }).setView(middle);

        builder.create().show();
    }

    /**
     * when on pause stage
     * */
    @Override
    protected void onPause() {
        super.onPause();
        EditText editLat = findViewById(R.id.editLat);
        EditText editLon = findViewById(R.id.editLon);
        SharedPreferences prefs = getSharedPreferences("FileName", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("ReserveName Lat", editLat.getText().toString());
        editor.putString("ReserveName Lon", editLon.getText().toString());
        editor.commit();
    }
} //End of Class EcarFinder

