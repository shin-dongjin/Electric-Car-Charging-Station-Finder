package com.example.finalproject;



//store the messages for db
public class NewsMessages{



    //Android Studio hint: to create getter and setter, put mouse on variable and click "alt+insert"
    protected String msg;
    protected int send;
    protected long id;

    /**Constructor:*/
    public NewsMessages(String n, int e, long i)
    {
        msg =n;
        send = e;
        id = i;
    }

    public void update(String n, int e)
    {
        msg = n;
        send = e;
    }

    /**Chaining constructor: */
    public NewsMessages(String n, int e) { this(n, e, 0);}


    public String getMsg() {
        return msg;
    }

    public int getInt() {
        return send;
    }

    public long getId() {
        return id;
    }

}
