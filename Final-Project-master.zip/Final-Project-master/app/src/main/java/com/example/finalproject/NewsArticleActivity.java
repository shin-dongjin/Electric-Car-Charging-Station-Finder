package com.example.finalproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import static com.example.finalproject.R.*;

//class that starts most activities
public class NewsArticleActivity extends AppCompatActivity {
    public static final String IS_FAVORITE_EXTRA = "IsFavorite";


    NewsDatabase dbOpener;
    SQLiteDatabase db;

    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_news_article);
//make DB obj
        dbOpener = new NewsDatabase(this);
        db = dbOpener.getWritableDatabase();
        dbOpener.onCreate(db);
//intent for news article activity, add the article to favorite
        NewsArticle article = (NewsArticle)getIntent().getSerializableExtra("NewsArticleActivity");
        boolean isFavorite = getIntent().getBooleanExtra(IS_FAVORITE_EXTRA, false);

        
        //dialog for deleting the favorite article from list
        Button b = findViewById(id.addFavoriteButton);
        if (isFavorite) {
            b.setText("Delete");
            b.setOnClickListener(view -> deleteFavorite(article));
        } else {
            b.setText("Add Favorite");
            b.setOnClickListener(view -> addFavorite(article));
        }

        TextView titleView = findViewById(id.title);
        titleView.setText(article.title);
        TextView descriptionView = findViewById(id.description);
        descriptionView.setText(article.description);

        TextView url = findViewById(id.url);
        url.setText(article.url);
        ImageView urlImage = findViewById(id.url_image);

        /* incomplete
        TODO
        Try to download and display the image
        URL req = null;
        try {
            req = new URL("http://java.sogeti.nl/JavaBlog/wp-content/uploads/2009/04/android_icon_256.png");
        } catch (MalformedURLException e) {
            // Aint no way this gonna happen
            e.printStackTrace();
        }
        Bitmap image = null;
        try {
            image = BitmapFactory.decodeStream(req.openConnection().getInputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
        urlImage.setImageBitmap(image);
        */

    }

    //dialog box for when you click on the list item inside favorites, asking if you want to delete the message
    void deleteFavorite(NewsArticle article) {
        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("Delete Alert");
        alertDialog.setMessage("Are you sure you want to delete?");
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE,"Delete",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        db.delete(NewsDatabase.TABLE_NAME, NewsDatabase.COL_TITLE + "=?", new String[]{article.title});
                        dialog.dismiss();
                        // Take me back captain!
                        finish();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE,"Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();


    }
    
    //add articles
    void addFavorite(NewsArticle article) {
        // Check if the favorite already exists before adding it
        // Hopefully this sanitizes my input so lil bobby drop tables doesnt get us
        String whereClause = NewsDatabase.COL_TITLE + " = ?";
        String[] whereArgs = new String[] {
                article.title
        };
        Cursor results = db.query(NewsDatabase.TABLE_NAME, new String[]{NewsDatabase.COL_TITLE, NewsDatabase.COL_DESCRIPTION, NewsDatabase.COL_URL, NewsDatabase.COL_URL_IMAGE}, whereClause, whereArgs, null, null, null);

        if (results.getCount() != 0) {
            finish();
            return;
        }

        ContentValues newRowValues = new ContentValues();
        //put string name in the NAME column:
        newRowValues.put(NewsDatabase.COL_TITLE, article.title);
        newRowValues.put(NewsDatabase.COL_DESCRIPTION, article.description);
        newRowValues.put(NewsDatabase.COL_URL, article.url);
        newRowValues.put(NewsDatabase.COL_URL_IMAGE, article.urlToImage);
        //insert in the database:
        db.insert(NewsDatabase.TABLE_NAME, null, newRowValues);

        finish();
    }

}
