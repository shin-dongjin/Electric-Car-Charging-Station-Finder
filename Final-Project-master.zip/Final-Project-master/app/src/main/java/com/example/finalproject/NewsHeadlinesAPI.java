package com.example.finalproject;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Arrays;

public class NewsHeadlinesAPI extends AppCompatActivity {
    /**
     * Intent to go to the News Headline page
     */
    // ArrayList<String> list = new ArrayList<>(Arrays.asList(" Stock Market ", " Traffic ", " Weather", " Politics "));

    // ArrayList<String> newsInfo = new ArrayList<>(Arrays.asList());
    APIListAdapter apiApdater;
    Button searchButton;
    Button asyncNews;
    CoordinatorLayout coordinatorLayout;
    ProgressBar progressBar;
    EditText searchEditText;
    ListView listView;

    private String msg;
    ArrayList<NewsArticle> list = new ArrayList<>(Arrays.asList());
    Snackbar sb;


    /**
     * Intent to go to the News Headline page
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.news_headlines_api);
        //  ListView myList = findViewById(R.id.newsListView);
        //   myList.setAdapter(apiApdater = new APIListAdapter());
        Toolbar tBar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(tBar);

        /** ListAdaptor in NewsAPI layout
         *  Toast for the news API list
         *
         *
         */
        //   myList.setOnItemClickListener((lv, vw, pos, id) -> {


        //   Toast.makeText(NewsHeadlinesAPI.this,
        //           "You clicked on:" + apiApdater.getItem(pos), Toast.LENGTH_SHORT).show();
        // });

        msg = "this is the News Searching API";
        //Show the toast immediately:
        // Toast.makeText(this, msg, Toast.LENGTH_LONG).show();

        //sb = Snackbar.make(tBar, "Welcome", Snackbar.LENGTH_LONG)
        //        .setAction("Do you want to go back?", e -> finish());

        /**SnackBar in NewsAPI layout
         *
         */
        View parentLayout = findViewById(android.R.id.content);
        /*
        Snackbar.make(parentLayout, "news headlines API Snackbar", Snackbar.LENGTH_LONG)
                .setAction("CLOSE", view -> {
                })
                .setActionTextColor(getResources().getColor(android.R.color.holo_red_light))
                .show();
         */
        searchButton = findViewById(R.id.typeofNews);
        searchButton.setOnClickListener(view -> searchNews());

        Button favoritesButton = findViewById(R.id.favoritesButton);
        favoritesButton .setOnClickListener(view -> startFavorites());

        //asyncNews = findViewById(R.id.typeofNews);
        //asyncNews.setOnClickListener(view-> startAsyncNews());

        searchEditText = findViewById(R.id.newsType);

        listView = findViewById(R.id.newsListView);
        apiApdater = new APIListAdapter();
        listView.setAdapter(apiApdater);

        progressBar = findViewById(R.id.progressBar);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu items for use in the action bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_layout, menu);

        MenuItem searchItem = menu.findItem(R.id.overflow);
        SearchView sView = (SearchView) searchItem.getActionView();
        sView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            //what to do when the menu item is selected:
            case R.id.item1:
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                break;

            case R.id.overflow:
                Toast.makeText(this, "This is the overflow menu", Toast.LENGTH_LONG).show();
                break;

            case R.id.search_item:
               openDialog();


                break;
        }
        return true;
    }



    /**
     * create dialog box obj to start the dialog box class
     */
    private void openDialog() {
        DialogBoxClass dialog = new DialogBoxClass();
        dialog.show(getSupportFragmentManager(), "API dialog");
    }

    private void searchNews() {
        progressBar.setVisibility(View.VISIBLE);

        Log.i(this.getClass().getName(), "Creating NewsQuery with list " + list);
        new NewsQuery(progressBar, list, searchEditText.getText().toString(), apiApdater).execute();

        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(searchEditText.getWindowToken(), 0);
    }

    private void startFavorites() {
        Intent intent = new Intent(this, NewsFavorites.class);
        startActivity(intent);
    }

    private class APIListAdapter extends BaseAdapter {

        public int getCount() {
            return list.size();
        } //This function tells how many objects to show


        public String getItem(int position) {
            return list.get(position).title;
        }  //This returns the string at position p

        public long getItemId(int p) {
            return p;
        } //This returns the database id of the item at position p


        /**
         * cycle through the view
         */
        public View getView(int p, View recycled, ViewGroup parent) {
            View thisRow = recycled;
            Log.i("status", "" + list);

            if (recycled == null)
                thisRow = getLayoutInflater().inflate(R.layout.news_headlines_table, null);




            TextView numberText = thisRow.findViewById(R.id.typeofNews);
            numberText.setText(getItem(p));
            thisRow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(NewsHeadlinesAPI.this, NewsArticleActivity.class);
                    intent.putExtra("NewsArticleActivity", list.get(p));
                    intent.putExtra(NewsArticleActivity.IS_FAVORITE_EXTRA, false);
                    startActivity(intent);
                }
            });

            return thisRow;
        }
    }
}