package com.example.finalproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * This class handled the favorite list that the user has saved
 *
 * @extends AppCompatActivity
 * */
public class EcarFavorite extends AppCompatActivity {
    private ArrayList<Ecar> favList = new ArrayList<>();
    private MyListAdapter myAdapter;
    private SQLiteDatabase db;
    private ImageButton deleteB;
    public static final String ITEM_SELECTED = "ITEM";
    public static final String ITEM_LATITUDE = "LATITUDE";
    public static final String ITEM_LONGITUDE = "LONGITUDE";
    public static final String ITEM_PHONE = "PHONE NUMBER";
    public static final String ITEM_ADDRESS = "ADDRESS";
    public static final String ITEM_POSTCODE = "POST CODE";
    public static final String ITEM_ID = "ID";
    public static final int EMPTY_ACTIVITY = 345;
    private ListView theList;

    /**
     * onCreate method
     *
     * @param savedInstanceState
     * */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ecar_favorite);

        theList = (ListView)findViewById(R.id.ecar_fav_list);

        //create an adapter object and send it to the listVIew
        myAdapter = new MyListAdapter();
        theList.setAdapter(myAdapter);

        //Start of SQLite Part (Selete Statement)
        // To Get A Database
        EcarDatabaseOpenHelper dbOpener = new EcarDatabaseOpenHelper(this);
        db = dbOpener.getWritableDatabase();

        // Query All the Results from the Database
        String [] columns = {EcarDatabaseOpenHelper.COL_ID, EcarDatabaseOpenHelper.COL_TITLE, EcarDatabaseOpenHelper.COL_LATITUDE, EcarDatabaseOpenHelper.COL_LONGITUDE,
                EcarDatabaseOpenHelper.COL_PHONE, EcarDatabaseOpenHelper.COL_ADDRESS, EcarDatabaseOpenHelper.COL_POSTCODE};
        Cursor results = db.query(false, EcarDatabaseOpenHelper.TABLE_NAME, columns,
                null, null, null, null, null, null);
        dbOpener.printCursor(results);
        results.moveToFirst();

        // Find the Column Indexes
        int idColIndex = results.getColumnIndex(EcarDatabaseOpenHelper.COL_ID);
        int titleColIndex = results.getColumnIndex(EcarDatabaseOpenHelper.COL_TITLE);
        int latitudeColIndex = results.getColumnIndex(EcarDatabaseOpenHelper.COL_LATITUDE);
        int longitudeColIndex = results.getColumnIndex(EcarDatabaseOpenHelper.COL_LONGITUDE);
        int phoneColIndex = results.getColumnIndex(EcarDatabaseOpenHelper.COL_PHONE);
        int addressColIndex = results.getColumnIndex(EcarDatabaseOpenHelper.COL_ADDRESS);
        int postcodeColIndex = results.getColumnIndex(EcarDatabaseOpenHelper.COL_POSTCODE);

        //iterate over the results, return true if there is a next item:
        while(results.moveToNext())
        {
            int id = Integer.parseInt(results.getString(idColIndex));
            String favTitle = results.getString(titleColIndex);
            String favLatitude = results.getString(latitudeColIndex);
            String favLongitude = results.getString(longitudeColIndex);
            String favPhone = results.getString(phoneColIndex);
            String favAddress = results.getString(addressColIndex);
            String favPostcode = results.getString(postcodeColIndex);

            //add the new Contact to the array list:
            favList.add(new Ecar(id, favTitle, favLatitude, favLongitude, favPhone, favAddress, favPostcode));
        }

        // End of SQLite Part (Selete Statement)
    }

    /**
     * Adapter inner class
     * */
    private class MyListAdapter extends BaseAdapter {

        /**
         * This function tells how many objects to show
         *
         * @return int
         * */
        public int getCount() {
            return favList.size();  }

        /**
         * This returns the string at position p
         *
         * @return Ecar
         * */
        public Ecar getItem(int position) {
            return favList.get(position);  }

        /**
         * This returns the database id of the item at position p
         *
         * @return long
         * */
        public long getItemId(int p) {
            return getItem(p).getId(); }
        /**
         * get the view and pass the bundle when the detail button has pressed
         *
         * @param p
         * @param recycled
         * @param parent
         *
         * @return p
         * */
        public View getView(int p, View recycled, ViewGroup parent)
        {

            LayoutInflater inflater = getLayoutInflater();
            View newView = inflater.inflate(R.layout.ecar_fav_row, parent, false );

            Ecar thisRow = getItem(p);
            TextView rowTitle = (TextView)newView.findViewById(R.id.row_title);

            deleteB = (ImageButton)newView.findViewById(R.id.eCar_deleteItem);
            deleteB.setOnClickListener(clk-> {
                deleteMessageId(getItemId(p));
            });

            boolean isTablet = findViewById(R.id.ecar_fragmentLocation) != null;
            Button detailB = (Button)newView.findViewById(R.id.eCar_detailItem);
            detailB.setOnClickListener( clk -> {

                Bundle dataToPass = new Bundle();
                dataToPass.putLong(ITEM_ID, getItemId(p));
                dataToPass.putString(ITEM_SELECTED, favList.get(p).getTitle() );
                dataToPass.putString(ITEM_LATITUDE, favList.get(p).getLat() );
                dataToPass.putString(ITEM_LONGITUDE, favList.get(p).getLon() );
                dataToPass.putString(ITEM_PHONE, favList.get(p).getPhone() );
                dataToPass.putString(ITEM_ADDRESS, favList.get(p).getAddress() );
                dataToPass.putString(ITEM_POSTCODE, favList.get(p).getPostcode() );

                if(isTablet)
                {
                    EcarDetailFragment dFragment = new EcarDetailFragment(); //add a DetailFragment
                    dFragment.setArguments( dataToPass ); //pass it a bundle for information
                    dFragment.setTablet(true);  //tell the fragment if it's running on a tablet or not
                    getSupportFragmentManager()
                            .beginTransaction()
                            .add(R.id.ecar_fragmentLocation, dFragment) //Add the fragment in FrameLayout
                            .addToBackStack("AnyName") //make the back button undo the transaction
                            .commit(); //actually load the fragment.
                }
                else //isPhone
                {
                    Intent nextActivity = new Intent(EcarFavorite.this, EcarEmpty.class);
                    nextActivity.putExtras(dataToPass); //send data to next activity
                    startActivityForResult(nextActivity, EMPTY_ACTIVITY); //make the transition
                }
            });

            rowTitle.setText("Title: " + thisRow.getTitle());

            //return the row:
            return newView;
        }
    }

    /**
     * when the delete button has pressed
     * dialog has opened
     *
     * @param p
     * */
    public void deleteMessageId(long p)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        AlertDialog dialog = builder.setTitle("Alert!")
                .setMessage("Do you want to delete?")
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        int i = db.delete(EcarDatabaseOpenHelper.TABLE_NAME, EcarDatabaseOpenHelper.COL_ID + "=?", new String[] {Long.toString(p)});
                        if(i != 0) {
                            favList.remove(p);

                            Log.i("Delete Row Confirm", "The Row has been deleted");
                        }else{
                            Log.i("Delete Row Confirm", "The Row has NOT been deleted");
                        }
                        //go back to previous page:
                        finish();
                        startActivity(getIntent());
                        myAdapter.notifyDataSetChanged();
                    }
                })
                //If you click the "Cancel" button:
                .setNegativeButton("Cancel", (d,w) -> {  /* nothing */})
                .create();

            //then show the dialog
            dialog.show();
    }
}
