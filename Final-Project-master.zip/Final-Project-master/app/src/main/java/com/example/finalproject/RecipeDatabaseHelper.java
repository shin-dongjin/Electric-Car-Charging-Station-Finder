package com.example.finalproject;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;



public class RecipeDatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "RecipeDatabaseHelper";
    public static final int VERSION_NUM = 1;
    public static final String TABLE_NAME = "FavoriteStation";
    public static final String COL_ID = "_id";
    public static final String COL_TITLE = "_title";


    /**
     * Constructor
     *
     * @param ctx
     * */


    public RecipeDatabaseHelper(Activity ctx) {
        super(ctx, DATABASE_NAME, null, VERSION_NUM);
    }

    /**
     * Database create query and execution
     *
     * @param db
     * */
    public void onCreate(SQLiteDatabase db)
    {
        //Make sure you put spaces between SQL statements and Java strings:
        db.execSQL("CREATE TABLE " + TABLE_NAME + "( "
                + COL_ID +" INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COL_TITLE + " TEXT"
                +")"
        );
    }

    /**
     *
     *
     *
     * @param db
     * @param oldVersion
     * @param newVersion
     *
     * */
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        Log.i("Database upgrade", "Old version:" + oldVersion + " newVersion:"+newVersion);

        //Delete the old table:
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);

        //Create a new table:
        onCreate(db);
    }

    /**
     *
     *
     *
     * @param db
     * @param oldVersion
     * @param newVersion
     *
     * */
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        Log.i("Database downgrade", "Old version:" + oldVersion + " newVersion:"+newVersion);

        //Delete the old table:
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);

        //Create a new table:
        onCreate(db);
    }

    /**
     *
     *
     * @param c
     *
     * */
    public void printCursor(Cursor c){


        Log.i("Position", ": "+c.getPosition());

        for(int i=0; i<c.getColumnCount(); i++)
        {
            Log.i("Name of the Column", ": "+c.getColumnName(i));
        }
        Log.i("Number of Results", ": "+c.getCount());
        int nameColIndex = c.getColumnIndex(RecipeDatabaseHelper.COL_TITLE);
        while(c.moveToNext())
        {
            String message = c.getString(nameColIndex);
            Log.i("Each row of results",": "+message);
        }
        c.moveToFirst();
    }
}