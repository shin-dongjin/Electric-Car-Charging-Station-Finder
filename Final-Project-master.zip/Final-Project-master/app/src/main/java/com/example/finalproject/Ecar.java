package com.example.finalproject;

public class Ecar {

    //Android Studio hint: to create getter and setter, put mouse on variable and click "alt+insert"
    /**
     * There are 7 elements for Ecar object
     * */
    protected String title, lat, lon, phone, address, postcode;
    protected int id;

    /**
     * Copied Constructor
     *
     * @param id
     * @param title
     * @param lat
     * @param lon
     * @param phone
     * @param address
     * @param postcode
     *
     * */
    public Ecar(int id, String title, String lat, String lon, String phone, String address, String postcode)
    {
        this.id = id;
        this.title = title;
        this.lat = lat;
        this.lon = lon;
        this.phone = phone;
        this.address = address;
        this.postcode = postcode;
    }

    /**
     * Copied Constructor
     *
     * @param t
     * @param p
     * @param i
     *
     * */
    public Ecar(String t, String p, int i)
    {
        title =t;
        phone = p;
        id = i;
    }

    /**
     * getter method for id
     *
     * @return long
     *
     * */
    public long getId() {
        return id;
    }

    /**
     * getter method for title
     *
     * @return string
     *
     * */
    public String getTitle() {
        return title;
    }

    /**
     * getter method for latitude
     *
     * @return string
     *
     * */
    public String getLat() {
        return lat;
    }

    /**
     * getter method for longitude
     *
     * @return string
     *
     * */
    public String getLon() {
        return lon;
    }

    /**
     * getter method for phone number
     *
     * @return string
     *
     * */
    public String getPhone() {
        return phone;
    }

    /**
     * getter method for address
     *
     * @return string
     *
     * */
    public String getAddress() {
        return address;
    }

    /**
     * getter method for postal code
     *
     * @return string
     *
     * */
    public String getPostcode() {
        return postcode;
    }
}
