package com.example.finalproject;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;


public class FindRecipes extends AppCompatActivity {
    private EditText editText;
    ListView recipesList;
    BaseAdapter myAdapter;
    Button btnSearch;

    ArrayList<Recipe> recipelist = new ArrayList<>();
    public static final String RecipeSharedString = "recipe";
    String urlRecipe = "http://torunski.ca/FinalProjectLasagna.json";
    SharedPreferences recipeShared;
    /**
     * Create method that shows all the information about recipe
     * @param savedInstanceState
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);
        recipesList = findViewById(R.id.recipesList);
        recipesList.setAdapter(myAdapter = new MyListAdapter());

        editText = findViewById(R.id.recipesEdit);
        recipeShared = getSharedPreferences("myPref.xml", MODE_PRIVATE);


        if (recipeShared.contains(RecipeSharedString)) {
            editText.setText(recipeShared.getString(RecipeSharedString, " "));
            SharedPreferences.Editor editor = recipeShared.edit();
            editor.apply();

        }
        recipesList.setOnItemClickListener(this::onItemClick);

        View parentLayout = findViewById(android.R.id.content);
        Snackbar.make(parentLayout, "Recipe Snackbar", Snackbar.LENGTH_LONG)
                .setAction("CLOSE", view -> {
                })
                .setActionTextColor(getResources().getColor(android.R.color.holo_red_light))
                .show();
        btnSearch = findViewById(R.id.recipesButt);
        btnSearch.setOnClickListener(view -> runQuery());



//        RecipeQuery query = new RecipeQuery();
//    query.execute(urlRecipe);
    }


//    private void openDialog() {
//        recipe_engine dialog = new recipe_engine();
//        dialog.show(getSupportFragmentManager(), "API dialog");
//    }

    /**
     * 
     * @param lv
     * @param vw
     * @param pos
     * @param id
     *
     * Open a new class with information about recipes.
     */

    private void onItemClick(AdapterView<?> lv, View vw, int pos, long id) {
        Toast.makeText(FindRecipes.this,
                "You clicked on:" + myAdapter.getItem(pos)+ "  "+recipelist.get(pos).f2f_url +
                        "  "+recipelist.get(pos).publisher
                , Toast.LENGTH_SHORT).show();


        Intent intentSave = new Intent(FindRecipes.this, SavedRecipes.class);
        intentSave.putExtra(" ", recipelist.get(pos).title + "    "+
                recipelist.get(pos).publisher + "    " +recipelist.get(pos).f2f_url);

                startActivity(intentSave);
    }


    private class MyListAdapter extends BaseAdapter {

        /**
         *
         * @return the size of the arrayList.
         */
        @Override
        public int getCount() {
            return recipelist.size();
        }


        /**
         * @param i
         * @return the titles of arrayList.
         */
        @Override
        public String getItem(int i) {
            return recipelist.get(i).title ;
        }

        /**
         * @param i
         * @return the item ids of the arrayList.
         */
        @Override
        public long getItemId(int i) {
            return Long.parseLong(recipelist.get(i).recipe_id);
        }

        /**
         * @param i
         * @param view
         * @param viewGroup
         * @return how the arrayList will be displayed.
         */
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {

            View thisRow = view;
            TextView result;

            if (thisRow == null) {
                thisRow = getLayoutInflater().inflate(R.layout.recipe_table, null);

//            TextView itemText = thisRow.findViewById(R.id.recipesType);
//            itemText.setText("Recipe Type");

                result = thisRow.findViewById(R.id.recipeSearched);
              
                result.setText(getItem(i));
            } else {
            }
            return thisRow;
        }


    }

    /**
     * @param menu
     * @return
     * Help icon.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.recipe_items, menu);
        return true;
    }

    /**
     * @param item
     * @return
     * Method that deals when the help icon gets clicked.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.RecipeInfo:
                RecipeInfo();
                break;
            case R.id.love:
                RecipeSaved();
                break;

        }
        return true;
    }

    /**
     * AlertBox with information about the program.
     */
    public void RecipeInfo() {
        View middle = getLayoutInflater().inflate(R.layout.recipe_help_menu,null);


        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Recipe Info")
                .setNegativeButton("Close", (dialog, id) -> {
                }).setView(middle);

        builder.create().show();
    }

    public void RecipeSaved() {

        Intent intent = new Intent(this,SavedRecipes.class);
        startActivity(intent);
    }

    /**
     *   Executes the database.
     */
    private void runQuery() {
        RecipeQuery theQuery = new RecipeQuery();
        theQuery.execute();
    }

    /**
     * Implementation of AsyncTask
     */
    class RecipeQuery extends AsyncTask<String, Integer, String> {
            String nu = null;

            @Override
            protected String doInBackground(String... strings) {
            try {
                //Connects to the server
                URL findRecipeUrl = new URL(urlRecipe);
                HttpURLConnection urlConnection = (HttpURLConnection) findRecipeUrl.openConnection();
                InputStream recipeStream = urlConnection.getInputStream();

                //Reading Json
                BufferedReader recipeReader = new BufferedReader(new InputStreamReader(recipeStream, StandardCharsets.UTF_8), 8);

                //Implementation of Gson
                Gson recipeGson = new Gson();
                RecipeJson recipeObject = recipeGson.fromJson(recipeReader, RecipeJson.class);

                recipelist = recipeObject.recipes;
            } catch (MalformedURLException e) {
                nu = "Url malformed";
            } catch (IOException e) {
                nu = "IO Exception";
            }
            return nu;
        }
    }

    /**
     *  Class of Json
     */
    static class RecipeJson {
        int count;
        ArrayList<Recipe> recipes;

    }

}
