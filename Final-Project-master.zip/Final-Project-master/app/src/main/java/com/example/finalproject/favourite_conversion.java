package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * This class shows the user's favourite conversions
 * @author Zhi
 * @version 1.0*/

/**
 * This class is for loading and viewing favourited conversion*/
public class favourite_conversion extends AppCompatActivity {
    ArrayList<currencyLoad> list = new ArrayList<>(Arrays.asList());
    String fromDb;
    String toDb;
    double original;
    String ret;
    double convDb;
    double res;
    BaseAdapter adapter;
    public static final String ITEM_SELECTED = "ITEM";
    public static final String ITEM_POSITION = "POSITION";
    public static final String ITEM_ID = "ID";
    public static final String ITEM_POSID ="POS";
    public static final int EMPTY_ACTIVITY = 345;
    CurrencyDatabaseOpener dbOpener;
    SQLiteDatabase db;
    /**
     * This method creates an instance of favourite conversion class, opens and load from database and also launches fragment layout*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite_conversion);
        ListView myList = findViewById(R.id.fav_list_convert);
        myList.setAdapter(adapter = new ListAdapter());
        boolean isTablet = findViewById(R.id.currenctFragmentLocation) !=null;
        myList.setOnItemClickListener((lv, vw, pos, id) -> Toast.makeText(favourite_conversion.this,
                "You clicked on:" + adapter.getItem(pos), Toast.LENGTH_SHORT).show());
        dbOpener = new CurrencyDatabaseOpener(this);
        db = dbOpener.getWritableDatabase();
        String [] columns = {CurrencyDatabaseOpener.COL_ID, CurrencyDatabaseOpener.COL_ORIGINAL, CurrencyDatabaseOpener.COL_FROM, CurrencyDatabaseOpener.COL_TO,CurrencyDatabaseOpener.COL_CONV};
        Cursor results = db.query(false, CurrencyDatabaseOpener.TABLE_NAME, columns, null, null, null, null, null, null);

        //find the column indices:
        int originalAmtIndex = results.getColumnIndex(CurrencyDatabaseOpener.COL_ORIGINAL);
        int fromColumnIndex = results.getColumnIndex(CurrencyDatabaseOpener.COL_FROM);
        int toColIndex = results.getColumnIndex(CurrencyDatabaseOpener.COL_TO);
        int convColIndex = results.getColumnIndex(CurrencyDatabaseOpener.COL_CONV);
        int idColIndex = results.getColumnIndex(CurrencyDatabaseOpener.COL_ID);
        while(results.moveToNext())
        {
            fromDb = results.getString(fromColumnIndex);
            original = results.getDouble(originalAmtIndex);
            toDb = results.getString(toColIndex);
            long id = results.getLong(idColIndex);
            convDb =results.getDouble(convColIndex);
            currencyLoad load = new currencyLoad(original+" "+fromDb+" TO "+toDb+": "+convDb,convDb,id);
            list.add(load);
            adapter.notifyDataSetChanged();
        }
        Button goBack = findViewById(R.id.goBack);
        goBack.setOnClickListener(v->finish());

        myList.setOnItemClickListener( (l, item, position, id) -> {

            Bundle dataToPass = new Bundle();
            dataToPass.putString(ITEM_SELECTED, list.get(position).getMsg());
            dataToPass.putInt(ITEM_POSITION, position);
            dataToPass.putLong(ITEM_ID, list.get(position).getId());
            dataToPass.putLong(ITEM_POSID, id);
            if(isTablet)
            {
                CurrencyDetailFragment dFragment = new CurrencyDetailFragment(); //add a DetailFragment
                dFragment.setArguments( dataToPass ); //pass it a bundle for information
                dFragment.setTablet(true);  //tell the fragment if it's running on a tablet or not
                getSupportFragmentManager()
                        .beginTransaction()
                        .add(R.id.currenctFragmentLocation, dFragment) //Add the fragment in FrameLayout
                        .addToBackStack("AnyName") //make the back button undo the transaction
                        .commit(); //actually load the fragment.
            }
            else //isPhone
            {
                Intent nextActivity = new Intent(favourite_conversion.this, CurrencyEmpty.class);
                nextActivity.putExtras(dataToPass); //send data to next activity
                startActivityForResult(nextActivity, EMPTY_ACTIVITY); //make the transition
            }
        });
    }

    private class ListAdapter extends BaseAdapter {

        /**
         * Tells the program how many objects to show
         * @return list.size()*/
        public int getCount() {
            return list.size();  }

        /**
         * Retrieves the array item at specific position
         * @param position
         * @return returns string at position*/
        public currencyLoad getItem(int position) {
            return list.get(position);  }

        /**
         * Returns the id of the item at position
         * @param p
         * @return p*/
        public long getItemId(int p) {
            return p; }

        /**
         * Sets object value in layout and inflates the view into list view*/
        public View getView(int p, View recycled, ViewGroup parent)
        {
            View thisRow = recycled;

            if(recycled == null){

                thisRow = getLayoutInflater().inflate(R.layout.currency_type_list, null);
                TextView itemText = thisRow.findViewById(R.id.checkBoxCurrency );
                itemText.setText(getItem(p).getMsg());

            }


            return thisRow;
        }


    }
    /**
     * This method returns results after previous activity ends*/
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == EMPTY_ACTIVITY)
        {
            if(resultCode == RESULT_OK) //if you hit the delete button instead of back button
            {
                long id = data.getLongExtra(ITEM_ID, 0);
                long posid = data.getLongExtra(ITEM_POSID,0);
                deleteMessageId((int)id,(int)posid);
            }
        }
    }


    /**
     * This method deletes from list and database*/
    public void deleteMessageId(int id,int posId)
    {

        list.remove(posId);
        db.delete(CurrencyDatabaseOpener.TABLE_NAME, CurrencyDatabaseOpener.COL_ID + "=?", new String[] {Integer.toString(id)});
        adapter.notifyDataSetChanged();
    }


}
