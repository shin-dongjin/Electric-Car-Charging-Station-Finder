package com.example.finalproject;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SavedRecipes extends AppCompatActivity {

    TextView textView;

    /**
     *
     * @param savedInstanceState
     */
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recipe_fragment);

        textView = findViewById(R.id.message_recipe);
        String listSaved = getIntent().getStringExtra(" ");
        textView.setText(listSaved);
    }
}
