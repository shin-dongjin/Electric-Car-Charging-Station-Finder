package com.example.finalproject;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

/**
 * This class so to set and view the deatil information on fragment
 *
 * @extends Fragment
 * */
public class EcarDetailFragment extends Fragment {

    private boolean isTablet;
    private Bundle dataFromActivity;
    private long id;

    public void setTablet(boolean tablet) { isTablet = tablet; }

    /**
     *  get the vaild information passed from the previous activity
     *  as a bundle and show on each view
     *
     * @param inflater
     * @param container
     * @param savedInstanceState
     *
     * @return View
     * */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        dataFromActivity = getArguments();

        // Inflate the layout for this fragment
        View result =  inflater.inflate(R.layout.ecar_fragment_detail, container, false);

        //show the id:
        TextView idView = (TextView)result.findViewById(R.id.fragment_id);
        id = dataFromActivity.getLong(EcarFavorite.ITEM_ID );
        idView.setText("ID: " + id);

        //show the title
        TextView title = (TextView)result.findViewById(R.id.fragment_title);
        title.setText("Title: "+dataFromActivity.getString(EcarFavorite.ITEM_SELECTED));

        //show the latitude
        TextView lat = (TextView)result.findViewById(R.id.fragment_latitude);
        lat.setText("Latitude: "+dataFromActivity.getString(EcarFavorite.ITEM_LATITUDE));

        //show the longitude
        TextView lon = (TextView)result.findViewById(R.id.fragment_longitude);
        lon.setText("Longitude: "+dataFromActivity.getString(EcarFavorite.ITEM_LONGITUDE));

        //show the phone
        TextView phone = (TextView)result.findViewById(R.id.fragment_phone);
        phone.setText("Phone Number: "+dataFromActivity.getString(EcarFavorite.ITEM_PHONE));

        //show the address
        TextView address = (TextView)result.findViewById(R.id.fragment_address);
        address.setText("Address: "+dataFromActivity.getString(EcarFavorite.ITEM_ADDRESS));

        //show the postcode
        TextView postcode = (TextView)result.findViewById(R.id.fragment_postcode);
        postcode.setText("Post Code: "+dataFromActivity.getString(EcarFavorite.ITEM_POSTCODE));

        return result;
    }
}
