package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
/**
 * @author Zhi
 * @version 1*/
public class CurrencyEmpty extends AppCompatActivity {
        /**
         * Empty class to launch {@link CurrencyDetailFragment}*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currency_empty);

        Bundle dataToPass = getIntent().getExtras();
        CurrencyDetailFragment dFragment = new CurrencyDetailFragment();
        dFragment.setArguments( dataToPass ); //pass data to the the fragment
        dFragment.setTablet(false); //tell the Fragment that it's on a phone.
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.currenctFragmentLocation, dFragment)
                .addToBackStack("AnyName")
                .commit();
    }
}
