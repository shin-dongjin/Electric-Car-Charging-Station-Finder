package com.example.finalproject;


public class Recipe {
    /**
     * Primitives from recipe.
     */
    public String publisher;
    public String f2f_url;
    public String title;
    public String source_url;
    public String recipe_id;
    public String image_url;
    public float social_rank;
    public String publisher_url;


}
