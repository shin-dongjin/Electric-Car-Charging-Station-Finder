package com.example.finalproject;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Arrays;

//class that holds all the favorite articles
public class NewsFavorites extends AppCompatActivity {
    /**
     * Intent to go to the News Headline page
     */
    // ArrayList<String> list = new ArrayList<>(Arrays.asList(" Stock Market ", " Traffic ", " Weather", " Politics "));

    // ArrayList<String> newsInfo = new ArrayList<>(Arrays.asList());
    APIListAdapter apiApdater;
    ListView listView;

    private String msg;
    ArrayList<NewsArticle> list = new ArrayList<>(Arrays.asList());
    Snackbar sb;

    /**
     * Intent to go to the News Headline page
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_favorites);
        Toolbar tBar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(tBar);

        msg = "this is the initial message";

        listView = findViewById(R.id.newsListView);
        apiApdater = new APIListAdapter();
        listView.setAdapter(apiApdater);
        getFavorites();
    }

    @Override
    protected void onPostResume() {
        Log.i(this.getClass().getName(), "--------- Running resume");
        super.onPostResume();
        list.clear();
        getFavorites();
        apiApdater.notifyDataSetChanged();
    }

    //make new DB obj, then query the obj within the list. get the results so they can be displayed
    void getFavorites() {
        NewsDatabase dbOpener = new NewsDatabase(this);
        SQLiteDatabase db = dbOpener.getWritableDatabase();
        dbOpener.onCreate(db);

        Cursor results = db.query(false, NewsDatabase.TABLE_NAME, new String[]{NewsDatabase.COL_TITLE, NewsDatabase.COL_DESCRIPTION, NewsDatabase.COL_URL, NewsDatabase.COL_URL_IMAGE}, null, null, null, null, null, null);
        while (results.moveToNext()) {
            String title = results.getString(results.getColumnIndex(NewsDatabase.COL_TITLE));
            String description = results.getString(results.getColumnIndex(NewsDatabase.COL_DESCRIPTION));
            String url = results.getString(results.getColumnIndex(NewsDatabase.COL_URL));
            String urlImage = results.getString(results.getColumnIndex(NewsDatabase.COL_URL_IMAGE));
            //add the new Contact to the array list:
            list.add(new NewsArticle(title, description, url, urlImage));
        }


    }

    //make options menu, inflate the menu options
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu items for use in the action bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_layout, menu);

        MenuItem searchItem = menu.findItem(R.id.overflow);
        SearchView sView = (SearchView) searchItem.getActionView();
        sView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        return true;

    }


    //list adapter that shows the objects in the list
    private class APIListAdapter extends BaseAdapter {

        public int getCount() {
            return list.size();
        } //This function tells how many objects to show


        public String getItem(int position) {
            return list.get(position).title;
        }  //This returns the string at position p

        public long getItemId(int p) {
            return p;
        } //This returns the database id of the item at position p


        /**
         * cycle through the view
         */
        public View getView(int p, View recycled, ViewGroup parent) {
            View thisRow = recycled;
            Log.i("status", "" + list);

            if (recycled == null)
                thisRow = getLayoutInflater().inflate(R.layout.news_headlines_table, null);




            TextView numberText = thisRow.findViewById(R.id.typeofNews);
            numberText.setText(getItem(p));
            thisRow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(NewsFavorites.this, NewsArticleActivity.class);
                    intent.putExtra("NewsArticleActivity", list.get(p));
                    intent.putExtra(NewsArticleActivity.IS_FAVORITE_EXTRA, true);
                    startActivity(intent);
                }
            });

            return thisRow;
        }
    }
}
