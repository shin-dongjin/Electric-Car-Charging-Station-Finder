package com.example.finalproject;

public class currencyLoad {
    protected String msg;
    protected double amt;
    protected long id;

    /**Constructor:*/
    public currencyLoad(String n, double e, long i)
    {
        msg =n;
        amt = e;
        id = i;
    }

    public void update(String n, double e)
    {
        msg = n;
        amt = e;
    }

    /**Chaining constructor: */
    public currencyLoad(String n, double e) { this(n, e, 0);}


    public String getMsg() {
        return msg;
    }

    public double getSent() {
        return amt;
    }

    public long getId() {
        return id;
    }
}
