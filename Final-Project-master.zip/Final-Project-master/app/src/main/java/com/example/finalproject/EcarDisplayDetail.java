package com.example.finalproject;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

/**
 *  This Class is to display the detail of an item's information
 *  that the user clicks from the list view
 *
 * @author Dongjin Shin
 * @Version 1.0
 * */
public class EcarDisplayDetail extends AppCompatActivity {

    /**
     * This is the create method that shows the detail information
     * such as location title, latitude, longitude and phone number
     * which item that user clicked from the list view
     *
     * @param savedInstanceState
     * @return null
     * */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ecar_display_detail);

        Toolbar tbar = (Toolbar)findViewById(R.id.eCarToolbar);
        setSupportActionBar(tbar);

        TextView titleView = findViewById(R.id.eCarLocationTitle);
        TextView latView = findViewById(R.id.eCarLatitude);
        TextView lonView = findViewById(R.id.eCarLongitude);
        TextView phoneView = findViewById(R.id.eCarPhone);

        String title = getIntent().getStringExtra("title");
        titleView.setText(title);

        String lat = getIntent().getStringExtra("lat");
        latView.setText(lat);

        String lon = getIntent().getStringExtra("lon");
        lonView.setText(lon);

        String phone = getIntent().getStringExtra("phone");
        phoneView.setText(phone);

        String address = getIntent().getStringExtra("address");
        String postcode = getIntent().getStringExtra("postcode");


        View parentLayout = findViewById(android.R.id.content);

        // To Get A Database
        EcarDatabaseOpenHelper dbOpener = new EcarDatabaseOpenHelper(this);
        SQLiteDatabase db = dbOpener.getWritableDatabase();

        // Load Google Map
        Bundle dataToPass = new Bundle();
        dataToPass.putString(lat, lon);

        Button googleButton = findViewById(R.id.eCarGoogleB);
        googleButton.setOnClickListener(clk -> {
            Uri gmmIntentUri = Uri.parse("google.streetview:cbll="+lat+","+lon);
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
            mapIntent.setPackage("com.google.android.apps.maps");
            startActivity(mapIntent);
        });

        // Press the save button to save the item to the favorite list
        Button saveButton = findViewById(R.id.eCarItemSave);
        saveButton.setOnClickListener(clk -> {
            //Snackbar.make(parentLayout ,"Results are found", Snackbar.LENGTH_LONG).show();

            //add to the database and get the new ID
            ContentValues newRowValues = new ContentValues();
            //put string title in the TITLE column:
            newRowValues.put(EcarDatabaseOpenHelper.COL_TITLE, title);

            newRowValues.put(EcarDatabaseOpenHelper.COL_LATITUDE, lat);
            newRowValues.put(EcarDatabaseOpenHelper.COL_LONGITUDE, lon);
            newRowValues.put(EcarDatabaseOpenHelper.COL_PHONE, phone);
            newRowValues.put(EcarDatabaseOpenHelper.COL_ADDRESS, address);
            newRowValues.put(EcarDatabaseOpenHelper.COL_POSTCODE, postcode);

            //insert in the database:
            long newId = db.insert(EcarDatabaseOpenHelper.TABLE_NAME, null, newRowValues);
            if(newId != -1) { // if insertion is successful
//                Intent moveFav = new Intent(this, EcarFavorite.class);
//                startActivity(moveFav);
                Snackbar.make(parentLayout ,"Successfully Save to Favorite!", Snackbar.LENGTH_LONG).show();
            }else{
                Snackbar.make(parentLayout ,"Oh... Something Wrong Happened... Please Try Again", Snackbar.LENGTH_LONG).show();
            }
            //favList.saveId(newId);
        });
    }

    /**
     * This method is to create option menu
     *
     * @Param menu
     * @Return boolean
     * */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu items for use in the action bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.ecar_toolbar_menu, menu);

        return true;
    }

    /**
     * This method is to do functions on each selected item
     *
     * @Param item MenuItem
     * @Return boolean
     * */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId())
        {
            //what to do when the menu item is selected:
            case R.id.ecarHelp:
                showDialogBox();
                break;
            case R.id.ecarFav:
                //TODO - Move to favorite list acitivity list
                Intent showFavList = new Intent(this, EcarFavorite.class);
                startActivity(showFavList);
                break;
        }
        return true;
    }

    /**
     * This method is to show dialog
     * */
    public void showDialogBox(){
        View middle = getLayoutInflater().inflate(R.layout.ecar_dialog_extra, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Instruction")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // What to do on Accept
                    }
                }).setView(middle);

        builder.create().show();
    }

}
