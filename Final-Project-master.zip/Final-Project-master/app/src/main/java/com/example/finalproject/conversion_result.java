package com.example.finalproject;


import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * This class converts currency and shows results to user
 *
 * @author Zhi
 * @version 1.0*/
public class conversion_result extends AppCompatActivity {

    String ret;
    double valueGot;
    double amt;
    double total;
    String from;
    String to;
    ProgressBar progressBar;
    String temp;
    Intent favIntent;




    /**
     * This class retrieves values from {@link ForeignCurrencyAPI}
     * and runs {@link conversion_result#runQuery()} with the values
     * {@link Button} back asks for user confirmation to go back
     * {@link Button} save, saves user preferences
     * {@link Button} fav goes to user's save preferences*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversion_result);
        from= getIntent().getStringExtra("from").toUpperCase();
        to=getIntent().getStringExtra("to").toUpperCase();
        temp=getIntent().getStringExtra("amount");
        amt=Double.parseDouble(temp);
        progressBar = findViewById(R.id.convertProcess);
        progressBar.setVisibility(View.VISIBLE);
        Button save = findViewById(R.id.save);
        Button fav =findViewById(R.id.fav);
        Button back = findViewById(R.id.goBack);

        CurrencyDatabaseOpener dbOpener = new CurrencyDatabaseOpener(this);
        SQLiteDatabase db = dbOpener.getWritableDatabase();

        back.setOnClickListener(view->{
            View parentLayout = findViewById(android.R.id.content);
            Snackbar.make(parentLayout, "Return?", Snackbar.LENGTH_LONG)
                    .setAction("Go back", view1 -> {finish();})
                    .setActionTextColor(getResources().getColor(android.R.color.holo_red_light ))
                    .show();
        });
        runQuery();
        favIntent = new Intent(this,favourite_conversion.class);
        save.setOnClickListener(v->{
            ContentValues newRowValues = new ContentValues();
            newRowValues.put(CurrencyDatabaseOpener.COL_ORIGINAL,Double.parseDouble(temp));
            newRowValues.put(CurrencyDatabaseOpener.COL_FROM, from);
            newRowValues.put(CurrencyDatabaseOpener.COL_TO, to);
            newRowValues.put(CurrencyDatabaseOpener.COL_CONV,total);
            long newId = db.insert(CurrencyDatabaseOpener.TABLE_NAME, null, newRowValues);
            favIntent.putExtra("newId",""+newId);
        });
        fav.setOnClickListener(view-> startActivity(favIntent) );
    }
    /**
     * Creates a reference to {@link currencyConversion} and executes*/
    public void runQuery(){
        currencyConversion convert = new currencyConversion();
        convert.execute();
    }

    /**
     * This class converts the currency {@link #amt} using {@link #from} and {@link #to}*/
    private class currencyConversion extends AsyncTask<String,Integer,String> {

        /**
         * This method connects to server, set up json object parser and retrieves value
         * @return  {@link #ret}*/
        @Override
        protected String doInBackground(String... strings) {
            String urlQuery ="https://api.exchangeratesapi.io/latest?base="+from+"&symbols="+to+"#";
            try {
                URL url = new URL(urlQuery);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream inStream = urlConnection.getInputStream();


                BufferedReader reader = new BufferedReader(new InputStreamReader(inStream, "UTF-8"), 8);
                StringBuilder sb = new StringBuilder();
                publishProgress(25);
                String line = null;
                while ((line = reader.readLine()) != null)
                {
                    sb.append(line + "\n");
                }
                String result = sb.toString();
                JSONObject jObject = new JSONObject(result);
                publishProgress(50);
                JSONObject convert = jObject.getJSONObject("rates");
                publishProgress(75);
                double value = convert.getDouble(to);
                valueGot=value;
                publishProgress(100);
            }
            catch(MalformedURLException mfe){ ret = "Malformed URL exception"; }
            catch(IOException ioe)          { ret = "IO Exception. Is the Wifi connected?";}
            catch (JSONException e) { ret="JSON error"; }


            return ret;
        }

        /**
         * After {@link currencyConversion#doInBackground(String...)}
         * this method executes to set values of layout */
        @Override                   //Type 3
        protected void onPostExecute(String sentFromDoInBackground) {
            super.onPostExecute(sentFromDoInBackground);
            //update GUI Stuff:
            progressBar.setVisibility(View.INVISIBLE);
            TextView tv = findViewById(R.id.convertResult);
            total=amt*valueGot;
            String amount = Double.toString(total);
            tv.setText(amt+" "+from+" TO "+to+": "+amount);

        }

        /**
         * This method executes everytime {@link currencyConversion#doInBackground(String...)} #publishProgress(Object[])}
         * is called*/
        @Override                       //Type 2
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            //Update GUI stuff only:
            progressBar.setMax(100);
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setProgress(values[0]);
        }
    }
}
