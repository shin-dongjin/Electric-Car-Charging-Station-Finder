package com.example.finalproject;



import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;





public class MainActivity extends AppCompatActivity {
    /**
     *This creates reference to image buttons and set click listener
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar tBar = findViewById(R.id.toolbar);
        setSupportActionBar(tBar);
        ImageButton car = findViewById(R.id.eCarImage);
        ImageButton news = findViewById(R.id.newsImage);
        ImageButton recipe = findViewById(R.id.recipeImage);
        ImageButton currency = findViewById(R.id.currencyImage);
        car.setOnClickListener(v->startCar());
        news.setOnClickListener(v-> startNews());
        recipe.setOnClickListener(v->startRecipe());
        currency.setOnClickListener(v->startAPI());
    }




    /**Intent to go to the electronic car page
     *
     */
    private void startCar(){
        Intent goToEcar = new Intent(this, EcarFinder.class);
        startActivity(goToEcar);
    }

    /**Intent to go to the Recipe page
     *
     */
    private void startRecipe() {
        Intent intent = new Intent(this, FindRecipes.class);
        startActivity(intent);

    }

    /**Intent to go to the News Headline page
     *
     */
    private void startNews() {
        Intent intent = new Intent(this, NewsHeadlinesAPI.class);
        startActivity(intent);
    }

    /**Intent to go to the Foreign Currency page
     *
     */
    private void startAPI() {
        Intent intent = new Intent(this, ForeignCurrencyAPI.class);
        startActivity(intent);
    }

    /**
     * This inflates the menu item layout
     *
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu items for use in the action bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_items, menu);
        return true;
    }

    /**
     *This makes menu item clickable
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId())
        {
            //what to do when the menu item is selected:
            case R.id.carMenu:
                startCar();
                break;
            case R.id.recipeMenu:
                startRecipe();
                break;
            case R.id.currencyMenu:
                startAPI();
                break;
            case R.id.newsMenu:
                startNews();
                break;
        }
        return true;
    }

}


