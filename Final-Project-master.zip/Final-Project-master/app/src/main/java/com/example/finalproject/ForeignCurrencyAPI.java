package com.example.finalproject;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Arrays;
import androidx.appcompat.widget.Toolbar;

/**
 * Foreign Currency Class, this class asks users for currency type, conversion type and amount to convert
 * and converts it
 *
 * @author Zhi
 * @version 1.0*/
public class ForeignCurrencyAPI extends AppCompatActivity {
    ArrayList<String> list = new ArrayList<String>(Arrays.asList());


    Button button;
    String fromType;
    String toType;
    String amount;
    TextView amt;
    TextView cTo;
    TextView cFrom;
    static SharedPreferences sharedpref;
    static SharedPreferences sharedpref2;
    String e;
    String g;
    public static final String mypref ="mypref";
    public static final String mypref2 ="mypref";
    public static final String EXTRA_TEXT ="com.example.finalproject.EXTRA_TEXT";
    public static final String EXTRA_TEXT2 ="com.example.finalproject.EXTRA_TEXT2";
    public static final String base="from";
    public static final String converted="to";

    /**
     * Uses @param savedInstanceState the {@link Bundle} instance
     * This method creates an instance of ForeignCurrency and checks for shared preferences
     * */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foreign_currency_api);

        Toolbar tBar = findViewById(R.id.currencyToolbar);
        setSupportActionBar(tBar);

        cFrom = findViewById(R.id.amountFrom);
        sharedpref = getSharedPreferences(mypref, Context.MODE_PRIVATE);
        if(sharedpref.contains(base)) {
            cFrom.setText(sharedpref.getString(base, ""));
        }

        cTo =findViewById(R.id.amountTo);
        sharedpref2 =getSharedPreferences(mypref2, Context.MODE_PRIVATE);
        if(sharedpref2.contains(converted)){
            cTo.setText(sharedpref2.getString(converted,""));
        }

        button = findViewById(R.id.convertButton);
        button.setOnClickListener(view->dialogBox() );


    }


    /**
     * Dialog box to confirm user's option*/
    public void dialogBox(){
        amt = findViewById(R.id.amountText);
        cFrom = findViewById(R.id.amountFrom);
        cTo = findViewById(R.id.amountTo);
        View view = getLayoutInflater().inflate(R.layout.foreign_currency_api_dialog,null);
        TextView fromDia = view.findViewById(R.id.fromDia);
        TextView toDia = view.findViewById(R.id.toDia);
        fromDia.setText(amt.getText().toString()+" "+cFrom.getText().toString());
        toDia.setText(cTo.getText().toString());

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(view).setTitle("Currency Conversion").setPositiveButton("Confirm", (dialog, id) -> {
            convertResult();

        }).setNegativeButton("Cancel", (dialogInterface, i) -> { });
        builder.create().show();
    }


    /**
     * Stores value to be retrieved and starts {@link conversion_result}*/
    public void convertResult(){
        amt = findViewById(R.id.amountText);
        cFrom = findViewById(R.id.amountFrom);
        cTo = findViewById(R.id.amountTo);
        Intent intent = new Intent(this,conversion_result.class);
        fromType =cFrom.getText().toString();
        toType = cTo.getText().toString();
        amount = amt.getText().toString();
        intent.putExtra("from",fromType);
        intent.putExtra("to",toType);
        intent.putExtra("amount",amount);
        amt.setText("");
        startActivity(intent);

    }

    /**
     * Inflate menu items for action bar usage*/
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.currency_items, menu);
        return true;
    }

    /**
     * Program's reaction when menu item is selected*/
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.currencyInfo:
                currencyInfo();
                break;
            case R.id.favConversion:
                startActivity(new Intent(this,favourite_conversion.class));
                break;
            case R.id.listConv:
                startActivity(new Intent(this,conv_list.class));
                break;
        }
        return true;
    }

    /**
     * Display layout information about how to use program*/
    public void currencyInfo()
    {
        View middle = getLayoutInflater().inflate(R.layout.currency_help_menu, null);


        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Currency Info")
                .setNegativeButton("Close", (dialog, id) -> {
                }).setView(middle);

        builder.create().show();
    }

    /**
     * this method saves previous entry*/
    @Override
    protected void onPause() {
        super.onPause();
        e =cFrom.getText().toString();
        g=cTo.getText().toString();
        SharedPreferences.Editor editor = sharedpref.edit();
        SharedPreferences.Editor editor2 = sharedpref2.edit();
        editor.putString(base,e);
        editor2.putString(converted,g);
        editor.commit();
        editor2.commit();
    }


}