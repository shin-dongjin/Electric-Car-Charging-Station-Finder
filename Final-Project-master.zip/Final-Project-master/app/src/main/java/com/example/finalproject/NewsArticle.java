package com.example.finalproject;

import java.io.Serializable;

//class to store the data for the list
public class NewsArticle implements Serializable {
//constructor with the arugments for list
    public NewsArticle(String title, String description, String url, String urlToImage) {
        this.title = title;
        this.description = description;
        this.url = url;
        this.urlToImage = urlToImage;
    }
    public String title, description, url, urlToImage;


}
