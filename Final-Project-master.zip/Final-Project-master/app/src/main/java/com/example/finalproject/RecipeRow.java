package com.example.finalproject;

import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class RecipeRow extends AppCompatActivity {

    public static final int PUSHED_DELETE = 35;
    public static final int PUSHED_UPDATE = 5338;

    protected SQLiteDatabase db = null;

    /**
     * Each row is showing the title, delete button and the detail button
     *
     * @param savedInstanceState
     * */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recipe_fragment);

        //get the database:
        RecipeDatabaseHelper opener = new RecipeDatabaseHelper(this);
        db =  opener.getWritableDatabase();

        //When you click on the delete button:
        Button deleteButton = (Button)findViewById(R.id.deleteRecipe);
        deleteButton.setOnClickListener(b -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            //This is the builder pattern, just call many functions on the same object:
            AlertDialog dialog = builder.setTitle("Alert!")
                    .setMessage("Do you want to delete?")
                    .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //set result to PUSHED_DELETE to show clicked the delete button
                            setResult(PUSHED_DELETE);
                            //go back to previous page:
                            finish();
                        }
                    })
                    //If you click the "Cancel" button:
                    .setNegativeButton("Cancel", (d,w) -> {  /* nothing */})
                    .create();

            //then show the dialog
            dialog.show();
        });
    }
}